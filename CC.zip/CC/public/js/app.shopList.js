angular.module('shopList', [])


	.directive('shopList', function() {
		return {
			controller: function() {
				console.log('Work!');
			}
		}
		});
