angular.module('routerApp', ['routerRoutes', 'ngAnimate', 'shopList'])

// create the controller and inject Angular's 
// this will be the controller for the ENTIRE site
.controller('mainController', function() {

    // create a bigMessage variable to display in our view
    this.bigMessage = 'A smooth sea never made a skilled sailor.';

})

// home page specific controller
.controller('homeController', function($scope) {
	$scope.shopItem = [
		id: 1
		category: 'Køkken- og spisestuetekstiler'
	]
},
	{
		id: 2
		category: 'Tøj'
	}

	})

// about page controller
.controller('aboutController', function() {
    this.message = 'about page.';
})

// shop page controller
.controller('shopController', function() {
    this.message = 'Shop!';
})

.controller('kontaktController', function() {
	this.message = 'Kontakt!';
});
