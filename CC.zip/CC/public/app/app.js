angular.module('routerApp', ['routerRoutes', 'ngAnimate', 'shopList'])

// create the controller and inject Angular's 
// this will be the controller for the ENTIRE site
.controller('mainController', function() {

    // create a bigMessage variable to display in our view
    this.bigMessage = 'A smooth sea never made a skilled sailor.';

})

// home page specific controller
.controller('homeController', function($scope) {
	
	vm.listItem1 = [
		{ img: '../../img/Dækserviet.jpeg', href: '/shop/produkt1'}, 
		{ img: '../../img/DobbeltDækserviet.jpeg', href: '/shop/produkt2' },
		{ img: '../../img/white.jpg' },
		{ img: '../../img/white.jpg' },
		{ img: '../../img/white.jpg' }				
	];


	vm.listItem2 = [
		{ img: '../../img/Poncho.jpeg', href: '/shop/produkt3'}, 
		{ img: '../../img/white.jpg' },
		{ img: '../../img/white.jpg' },
		{ img: '../../img/white.jpg' },
		{ img: '../../img/white.jpg' }					
	];

	});

// about page controller
.controller('aboutController', function() {
    this.message = 'about page.';
})

// shop page controller
.controller('shopController', function() {
    this.message = 'Shop!';
})

.controller('kontaktController', function() {
	this.message = 'Kontakt!';
});
