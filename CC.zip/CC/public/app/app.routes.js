// inject ngRoute for all our routing needs
angular.module('routerRoutes', ['ngRoute'])

// configure our routes
.config(function($routeProvider, $locationProvider) {
    $routeProvider

        // route for the home page
        .when('/', {
            templateUrl : 'views/pages/forside.html',
            controller  : 'homeController',
            controllerAs: 'home'
        })

        // route for the about page
        .when('/om', {
            templateUrl : 'views/pages/om.html',
            controller  : 'aboutController',
            controllerAs: 'about'
        })

        // route for the shop page
        .when('/shop', {
            templateUrl : 'views/pages/shop.html',
            controller  : 'contactController',
            controllerAs: 'contact'
        })

        // route for the contact page
        .when('/kontakt', {
            templateUrl : 'views/pages/kontakt.html',
            controller  : 'kontaktController',
            controllerAs: 'kontakt'
        })

        // route for the product page
        .when('/shop/produkt1', {
            templateUrl : 'views/pages/produkter/produkt1.html',
        })

        // route for the product page
        .when('/shop/produkt2', {
            templateUrl : 'views/pages/produkter/produkt2.html',
        })

        // route for the product page
        .when('/shop/produkt3', {
            templateUrl : 'views/pages/produkter/produkt3.html',
        })

        // route for the product page
        .when('/shop/produkt4', {
            templateUrl : 'views/pages/produkter/produkt4.html',
        })

        // route for the product page
        .when('/shop/produkt5', {
            templateUrl : 'views/pages/produkter/produkt5.html',
        });

    $locationProvider.html5Mode(true);
});